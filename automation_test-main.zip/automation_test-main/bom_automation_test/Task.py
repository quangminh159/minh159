from Bom import Bom


class TaskSimpleData:
    def __init__(self):
        self.name_of_task = ""
        self.list_boms = list()
