from JobcardClass import TabJob

class JobCardSimpleData:
    def __init__(self):
        self.name_of_jobcard = ""
        self.list_tabjobs = list()
        self.list_jobcards = list()
        self.list_staffs = list()
        self.list_tasks = list()
        